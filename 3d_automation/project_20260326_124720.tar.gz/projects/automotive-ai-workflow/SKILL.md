---
name: automotive-ai-workflow
description: 汽车设计AI全流程工作流，覆盖从概念草图到生产数据的完整3D建模流程；当用户需要进行汽车概念设计验证、油泥模型数字化、精细化曲面建模、VR评审准备或工程数据交接时使用
dependency:
  python:
    - coze-workload-identity==0.1.7
---

# 汽车设计 AI 全流程工作流

## 概述

本工作流覆盖汽车设计的完整生命周期，从概念草图到生产级数据。

## 阶段总览

```
概念探索 → 设计验证 → 精细化建模 → 工程交接
  (AI主导)    (AI辅助)     (传统主导)    (数据输出)
```

---

## 阶段 1：概念探索（AI 主导）

### 1.1 概念草图 → 3D 模型

**工具**：TripoSG / Meshy

**输入**：概念设计草图（侧面视角最佳，1024x1024+）

**流程**：
1. 准备高质量概念草图
2. 上传至 TripoSG（https://tripo.ai）
3. 生成 3D 模型（2-5分钟）
4. 导出 GLB 格式
5. Blender 导入检查

**参考**：[references/concept-to-3d.md](references/concept-to-3d.md)

---

### 1.2 文本 → 3D 概念

**工具**：Meshy Text-to-3D

**输入**：文本描述

**描述模板**：
```
[车型类型] + [整体形态] + [关键特征] + [材质/颜色] + [风格]
示例：一辆红色跑车，流线型车身，低矮车顶，大尺寸轮毂，金属漆面，现代简约风格
```

---

## 阶段 2：设计验证（AI 辅助）

### 2.1 油泥模型 → 3D 扫描

**工具**：Luma AI APP

**流程**：
1. 围绕油泥模型缓慢移动拍摄（2-3分钟）
2. 云端处理（20-40分钟）
3. 下载 GLB 模型
4. Blender 优化

**参考**：[references/clay-scan.md](references/clay-scan.md)

---

### 2.2 VR 评审准备

**工具**：Unity / Sketchfab / Blender

**流程**：
1. 导入模型到 VR 软件
2. 设置 1:1 比例场景
3. 配置 VR 设备
4. 团队评审

---

## 阶段 3：精细化建模（传统主导）

### 3.1 拓扑优化

**工具**：Instant Mesh、Blender QuadRemesher

**目标**：AI 粗模 → 四边形网格 → 可导入 Alias

**流程**：
1. Instant Mesh 在线处理（推荐）
2. Blender 手动修复特征线
3. 导出 OBJ/FBX

**参考**：[references/topology-optimization.md](references/topology-optimization.md)

---

### 3.2 A 级曲面建模

**工具**：Alias / Blender

**核心要求**：
- G2 曲率连续（A 级曲面标准）
- 四边形网格
- 无三角面在可见区域

**检查工具**：
- F5：斑马纹分析（Zebra）
- F6：高光线（Highlight Lines）
- F7：曲率梳（Curvature Comb）

**参考**：[references/alias-modeling.md](references/alias-modeling.md)

---

### 3.3 关键曲面建模

**主要部件**：

| 部件 | 难度 | 关键要点 |
|------|------|---------|
| 发动机盖 | 中 | 与翼子板/风挡 G2 连续 |
| 车门 | 中 | 腰线特征、门把手细节 |
| 侧围 | 高 | 整体造型线、轮眉 |
| 顶棚 | 中 | 与侧围/风挡对接 |
| B 柱 | 高 | 上下端 G2 连续 |

**参考**：[references/car-parts-modeling.md](references/car-parts-modeling.md)

---

## 阶段 4：渲染输出

### 4.1 Blender 精细化渲染

**材质设置**：
- 车身：Metallic 0.9, Roughness 0.1-0.2, Clearcoat 1.0
- 车窗：Transmission 1.0, IOR 1.45
- 轮毂：拉丝金属效果

**灯光**：HDRI 汽车展示 + 三点光源

---

### 4.2 输出清单

```
静态渲染：
□ 正面 / 侧面 / 3/4 角
□ 细节特写（车头、车尾、轮毂）
□ 内饰视角（如有）

视频：
□ 360° 旋转（10-15秒）
□ 环绕展示
```

---

## 阶段 5：工程数据交接

### 5.1 数据格式

| 格式 | 用途 | 接收方 |
|------|------|--------|
| IGES | A 级曲面 | 工程 CAD |
| STEP | 实体模型 | CATIA/UG |
| JT | 轻量化 | 评审 |

### 5.2 交接清单

```
□ A 级曲面数据（IGES）
□ 渲染图（PNG/JPG）
□ 展示视频（MP4）
□ 设计说明文档
□ 关键尺寸标注
```

---

## 工具选择速查

| 任务 | 推荐工具 |
|------|---------|
| 快速体验 | Luma AI APP |
| 单图建模 | TripoSG |
| 文本生成 | Meshy |
| 多视角建模 | Meshy Image-to-3D |
| 拓扑优化 | Instant Mesh |
| A 级曲面 | Alias |
| 渲染 | Blender / VRED |

---

## 质量标准

| 阶段 | 精度 | 适用场景 |
|------|------|---------|
| 概念级 | ±5-10mm | 快速验证 |
| 验证级 | ±1-2mm | 设计评审 |
| 生产级 | ±0.1mm | 工程参考 |

---

## 完整案例流程

**目标**：完成一辆车的 3D 建模

**步骤**：

1. **概念设计** → 绘制或获取概念草图
2. **TripoSG** → 生成初始 3D 模型
3. **Blender 优化** → 修复拓扑、调整形态
4. **Alias 精细化** → A 级曲面（发动机盖、车门、侧围等）
5. **Blender 渲染** → 材质、灯光、输出
6. **工程输出** → IGES/STEP 交接

---

## 注意事项

- 仅在需要时读取参考文档，保持上下文简洁
- 充分利用 AI 工具加速概念阶段，传统工具保证精度
- 交接前确保数据格式与工程团队确认

## 视频生成能力

### 即梦 AI Seedance 2.0 视频生成

**工具**：即梦 AI Seedance 2.0 (火山引擎)

**用途**：生成概念车展示视频、使用场景演示

**调用方式**：执行 `scripts/generate_video.py` 脚本

**前置条件**：
- 需配置火山引擎 AccessKey 凭证
- 凭证格式：`access_key:secret_key`

**生成参数**：
- 时长：5秒 或 10秒
- 分辨率：1080P
- 比例：16:9 / 9:16 / 1:1 等

**使用示例**：
```bash
# 生成单个场景视频
python scripts/generate_video.py

# 脚本会依次生成4个场景的10秒短视频
```

**参考**：视频生成 API 文档详见火山引擎官方文档

## 资源索引

- 概念草图转3D：[references/concept-to-3d.md](references/concept-to-3d.md)
- 油泥模型扫描：[references/clay-scan.md](references/clay-scan.md)
- 拓扑优化：[references/topology-optimization.md](references/topology-optimization.md)
- Alias 基础操作：[references/alias-modeling.md](references/alias-modeling.md)
- 具体部件建模：[references/car-parts-modeling.md](references/car-parts-modeling.md)
