#!/usr/bin/env python3
"""
即梦AI视频生成脚本 - Seedance 2.0
用于生成2035年新能源跨物种跨星际交通车使用场景短视频

授权方式: ApiKey (火山引擎 AccessKey)
凭证Key: COZE_VOLCENGINE_JIMENG_<skill_id>
"""

import os
import json
import time
import hashlib
import hmac
import base64
from datetime import datetime, timezone
from urllib.parse import quote

# 使用 coze_workload_identity 的 requests
from coze_workload_identity import requests


class JimengVideoGenerator:
    """即梦AI视频生成器"""
    
    def __init__(self, access_key: str, secret_key: str):
        self.access_key = access_key
        self.secret_key = secret_key
        self.base_url = "https://visual.volcengineapi.com"
        self.region = "cn-north-1"
        self.service = "cv"
        self.version = "2022-08-31"
    
    def _sign_request(self, method: str, path: str, query_params: dict, body: str) -> dict:
        """
        生成火山引擎 API 签名
        参考: https://www.volcengine.com/docs/6369/67268
        """
        # 时间戳
        now = datetime.now(timezone.utc)
        amz_date = now.strftime("%Y%m%dT%H%M%SZ")
        date_stamp = now.strftime("%Y%m%d")
        
        # 构建 Query String
        query_string = "&".join(f"{quote(k, safe='')}={quote(v, safe='')}" for k, v in sorted(query_params.items()))
        
        # 构建 Canonical Request
        canonical_headers = f"content-type:application/json\nhost:visual.volcengineapi.com\nx-content-sha256:{hashlib.sha256(body.encode()).hexdigest()}\nx-date:{amz_date}\n"
        signed_headers = "content-type;host;x-content-sha256;x-date"
        
        payload_hash = hashlib.sha256(body.encode()).hexdigest()
        canonical_request = f"{method}\n{path}\n{query_string}\n{canonical_headers}\n{signed_headers}\n{payload_hash}"
        
        # 构建 String to Sign
        credential_scope = f"{date_stamp}/{self.region}/{self.service}/request"
        string_to_sign = f"HMAC-SHA256\n{amz_date}\n{credential_scope}\n{hashlib.sha256(canonical_request.encode()).hexdigest()}"
        
        # 计算签名
        k_date = hmac.new(self.secret_key.encode(), date_stamp.encode(), hashlib.sha256).digest()
        k_region = hmac.new(k_date, self.region.encode(), hashlib.sha256).digest()
        k_service = hmac.new(k_region, self.service.encode(), hashlib.sha256).digest()
        k_signing = hmac.new(k_service, "request".encode(), hashlib.sha256).digest()
        signature = hmac.new(k_signing, string_to_sign.encode(), hashlib.sha256).hexdigest()
        
        # 构建 Authorization Header
        authorization = f"HMAC-SHA256 Credential={self.access_key}/{credential_scope}, SignedHeaders={signed_headers}, Signature={signature}"
        
        return {
            "Content-Type": "application/json",
            "Host": "visual.volcengineapi.com",
            "X-Date": amz_date,
            "X-Content-Sha256": payload_hash,
            "Authorization": authorization
        }
    
    def submit_task(self, prompt: str, frames: int = 241, aspect_ratio: str = "16:9") -> str:
        """
        提交视频生成任务
        
        Args:
            prompt: 视频描述提示词
            frames: 帧数 (121=5秒, 241=10秒)
            aspect_ratio: 视频比例
        
        Returns:
            task_id: 任务ID
        """
        body = json.dumps({
            "req_key": "jimeng_t2v_v30_1080p",
            "prompt": prompt,
            "seed": -1,
            "frames": frames,
            "aspect_ratio": aspect_ratio
        })
        
        query_params = {
            "Action": "CVSync2AsyncSubmitTask",
            "Version": self.version
        }
        
        headers = self._sign_request("POST", "/", query_params, body)
        
        url = f"{self.base_url}?Action=CVSync2AsyncSubmitTask&Version={self.version}"
        
        response = requests.post(url, headers=headers, data=body, timeout=30)
        
        if response.status_code >= 400:
            raise Exception(f"HTTP请求失败: 状态码 {response.status_code}, 响应内容: {response.text}")
        
        result = response.json()
        
        if result.get("code") != 10000:
            raise Exception(f"API错误: {result.get('message')}")
        
        task_id = result.get("data", {}).get("task_id")
        if not task_id:
            raise Exception("未获取到 task_id")
        
        return task_id
    
    def query_task(self, task_id: str) -> dict:
        """
        查询任务状态
        
        Args:
            task_id: 任务ID
        
        Returns:
            dict: 包含 status 和 video_url 的结果
        """
        body = json.dumps({
            "req_key": "jimeng_t2v_v30_1080p",
            "task_id": task_id
        })
        
        query_params = {
            "Action": "CVSync2AsyncGetResult",
            "Version": self.version
        }
        
        headers = self._sign_request("POST", "/", query_params, body)
        
        url = f"{self.base_url}?Action=CVSync2AsyncGetResult&Version={self.version}"
        
        response = requests.post(url, headers=headers, data=body, timeout=30)
        
        if response.status_code >= 400:
            raise Exception(f"HTTP请求失败: 状态码 {response.status_code}, 响应内容: {response.text}")
        
        result = response.json()
        
        if result.get("code") != 10000:
            raise Exception(f"API错误: {result.get('message')}")
        
        data = result.get("data", {})
        return {
            "status": data.get("status"),
            "video_url": data.get("video_url"),
            "done": data.get("status") == "done"
        }
    
    def generate_video(self, prompt: str, frames: int = 241, aspect_ratio: str = "16:9", 
                       max_wait: int = 600, poll_interval: int = 10) -> str:
        """
        生成视频（提交任务并等待完成）
        
        Args:
            prompt: 视频描述提示词
            frames: 帧数 (121=5秒, 241=10秒)
            aspect_ratio: 视频比例
            max_wait: 最大等待时间（秒）
            poll_interval: 轮询间隔（秒）
        
        Returns:
            str: 视频URL
        """
        print(f"提交视频生成任务...")
        print(f"提示词: {prompt[:100]}...")
        
        task_id = self.submit_task(prompt, frames, aspect_ratio)
        print(f"任务已提交，task_id: {task_id}")
        
        start_time = time.time()
        
        while True:
            elapsed = time.time() - start_time
            if elapsed > max_wait:
                raise Exception(f"任务超时，已等待 {max_wait} 秒")
            
            result = self.query_task(task_id)
            status = result.get("status")
            
            print(f"[{int(elapsed)}秒] 状态: {status}")
            
            if status == "done":
                video_url = result.get("video_url")
                if video_url:
                    print(f"视频生成成功!")
                    return video_url
                else:
                    raise Exception("任务完成但未获取到视频URL")
            elif status == "expired":
                raise Exception("任务已过期")
            elif status == "not_found":
                raise Exception("任务未找到")
            
            time.sleep(poll_interval)


def main():
    """主函数 - 生成4个场景的10秒短视频"""
    
    # 获取凭证
    skill_id = "7621182441138536484"
    credential = os.getenv(f"COZE_VOLCENGINE_JIMENG_{skill_id}")
    
    if not credential:
        print("错误: 未找到火山引擎凭证")
        print("请设置环境变量 COZE_VOLCENGINE_JIMENG_<skill_id>")
        return
    
    # 解析凭证 (假设格式为 "access_key:secret_key")
    parts = credential.split(":")
    if len(parts) != 2:
        print("错误: 凭证格式不正确，应为 'access_key:secret_key'")
        return
    
    access_key, secret_key = parts
    
    # 初始化生成器
    generator = JimengVideoGenerator(access_key, secret_key)
    
    # 定义4个场景
    scenes = [
        {
            "name": "场景1-太空港高速穿梭",
            "prompt": "电影级镜头：一辆流线型银色悬浮跑车在巨大的太空站内部高速飞行，蓝色等离子能量尾迹划过，宇航员在零重力环境漂浮，巨大窗户可见地球和星空，科幻电影质感，运动模糊效果，8K高清，充满速度感和未来感"
        },
        {
            "name": "场景2-星际生物接驳",
            "prompt": "电影级镜头：一艘圆形星际悬浮舱缓缓停靠在外星人空间站，舱门打开，多种外星智慧生物排队登舱，生物发光照明，全息投影标识，未来主义建筑风格，不同体型的乘客入座，和谐共处的星际场景，8K高清"
        },
        {
            "name": "场景3-外星探索科考",
            "prompt": "电影级镜头：一辆方正的科考车在外星沙漠行星表面行驶，天空有两个橙色太阳，怪异岩石 formations，科研人员采集样本，远处有穹顶栖息地，戏剧性光影效果，荒凉而神秘的异星氛围，8K高清"
        },
        {
            "name": "场景4-星际巡航探险",
            "prompt": "电影级镜头：一艘鲨鱼造型的星际巡航舰穿越深空小行星带，背景是紫色粉色星云和遥远行星，驾驶舱可见探险家飞行员，曲速引擎发光，史诗级太空冒险场景，8K高清电影质感"
        }
    ]
    
    results = []
    
    for i, scene in enumerate(scenes, 1):
        print(f"\n{'='*60}")
        print(f"生成 {scene['name']}")
        print(f"{'='*60}")
        
        try:
            video_url = generator.generate_video(
                prompt=scene["prompt"],
                frames=241,  # 10秒
                aspect_ratio="16:9",
                max_wait=600,
                poll_interval=15
            )
            
            results.append({
                "scene": scene["name"],
                "status": "success",
                "video_url": video_url
            })
            print(f"✓ {scene['name']} 生成成功")
            print(f"  视频URL: {video_url}")
            
        except Exception as e:
            results.append({
                "scene": scene["name"],
                "status": "failed",
                "error": str(e)
            })
            print(f"✗ {scene['name']} 生成失败: {e}")
    
    # 输出结果汇总
    print(f"\n{'='*60}")
    print("生成结果汇总")
    print(f"{'='*60}")
    
    for r in results:
        status_icon = "✓" if r["status"] == "success" else "✗"
        print(f"{status_icon} {r['scene']}: {r['status']}")
        if r["status"] == "success":
            print(f"  URL: {r['video_url']}")
        else:
            print(f"  错误: {r['error']}")
    
    # 保存结果到文件
    output_file = "/workspace/projects/video_results.json"
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"\n结果已保存到: {output_file}")


if __name__ == "__main__":
    main()
